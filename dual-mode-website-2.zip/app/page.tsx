"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Heart,
  Stethoscope,
  Sun,
  Moon,
  Activity,
  FileText,
  Calendar,
  MessageSquare,
  BarChart3,
  Users,
  BookOpen,
  ClipboardList,
  CheckCircle,
  Shield,
  Quote,
} from "lucide-react"

export default function Home() {
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const [hoveredMode, setHoveredMode] = useState<"patient" | "clinician" | null>(null)

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background via-background to-primary/5">
      {/* Theme toggle in corner */}
      <div className="absolute top-6 right-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="rounded-full"
        >
          <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </div>

      {/* Main content */}
      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-5xl">
          {/* Logo and title */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-primary/10">
                <Activity className="h-10 w-10 text-primary" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">MedReport AI</h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              AI-powered medical report analysis with personalized insights for patients and healthcare professionals
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-3 mb-10">
            <Badge variant="secondary" className="px-4 py-2 text-sm gap-2">
              <FileText className="h-4 w-4" />
              Demo with 5+ Reports
            </Badge>
            <Badge variant="secondary" className="px-4 py-2 text-sm gap-2">
              <Users className="h-4 w-4" />
              Two-Mode Outputs
            </Badge>
            <Badge variant="secondary" className="px-4 py-2 text-sm gap-2">
              <BookOpen className="h-4 w-4" />
              Citation List
            </Badge>
          </div>

          {/* Mode selection cards */}
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {/* Patient Mode Card */}
            <Card
              className={`relative overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-[1.02] border-2 ${
                hoveredMode === "patient" ? "border-primary shadow-lg" : "border-transparent"
              }`}
              onMouseEnter={() => setHoveredMode("patient")}
              onMouseLeave={() => setHoveredMode(null)}
              onClick={() => router.push("/patient")}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/20 to-transparent rounded-bl-full" />
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2.5 rounded-xl bg-primary/10">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl">Patient Mode</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Simple explanations of your medical reports in easy-to-understand language
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <BarChart3 className="h-4 w-4 text-primary" />
                    <span>Dashboard & Health Analytics</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <MessageSquare className="h-4 w-4 text-primary" />
                    <span>Messages with Healthcare Team</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span>Appointment Management</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4 text-primary" />
                    <span>Lab & Radiology Report Scans</span>
                  </div>
                </div>
                <Button className="w-full mt-6" size="lg">
                  Enter Patient Portal
                </Button>
              </CardContent>
            </Card>

            {/* Clinician Mode Card */}
            <Card
              className={`relative overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-[1.02] border-2 ${
                hoveredMode === "clinician" ? "border-accent shadow-lg" : "border-transparent"
              }`}
              onMouseEnter={() => setHoveredMode("clinician")}
              onMouseLeave={() => setHoveredMode(null)}
              onClick={() => router.push("/clinician")}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-accent/20 to-transparent rounded-bl-full" />
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2.5 rounded-xl bg-accent/10">
                    <Stethoscope className="h-6 w-6 text-accent" />
                  </div>
                  <CardTitle className="text-2xl">Clinician Mode</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Professional clinical summaries with critical values and guideline references
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <ClipboardList className="h-4 w-4 text-accent" />
                    <span>Clinical Dashboard & Overview</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 text-accent" />
                    <span>Booked Appointments</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Users className="h-4 w-4 text-accent" />
                    <span>Patient History Records</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <BookOpen className="h-4 w-4 text-accent" />
                    <span>Medical Library & Guidelines</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4 text-accent" />
                    <span>Lab & Radiology Report Analysis</span>
                  </div>
                </div>
                <Button className="w-full mt-6 bg-accent hover:bg-accent/90 text-accent-foreground" size="lg">
                  Enter Clinician Portal
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mt-10">
            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
              <Shield className="h-5 w-5 text-primary shrink-0" />
              <div>
                <p className="text-sm font-medium">Privacy First</p>
                <p className="text-xs text-muted-foreground">Synthetic data only, HIPAA compliant</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
              <Quote className="h-5 w-5 text-primary shrink-0" />
              <div>
                <p className="text-sm font-medium">Cited Sources</p>
                <p className="text-xs text-muted-foreground">RSNA, CDC, NIH, ACC/AHA guidelines</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
              <CheckCircle className="h-5 w-5 text-primary shrink-0" />
              <div>
                <p className="text-sm font-medium">Safety Focused</p>
                <p className="text-xs text-muted-foreground">Clear disclaimers, red flag alerts</p>
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <p className="text-center text-xs text-muted-foreground mt-10 max-w-xl mx-auto">
            This tool is for educational purposes only and does not provide medical diagnoses. Always consult a
            qualified healthcare provider for medical advice. Uses synthetic/de-identified data only.
          </p>
        </div>
      </main>
    </div>
  )
}
