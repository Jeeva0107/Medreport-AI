"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, Video, Plus, Check } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"

const initialUpcomingAppointments = [
  {
    id: 1,
    doctor: "Dr. Sarah Johnson",
    specialty: "Primary Care",
    date: "Jan 15, 2026",
    time: "10:00 AM",
    type: "In-Person",
    location: "Medical Center, Room 204",
    canCheckIn: true,
  },
  {
    id: 2,
    doctor: "Dr. Michael Chen",
    specialty: "Cardiology",
    date: "Jan 22, 2026",
    time: "2:30 PM",
    type: "Video",
    location: "Telehealth",
    canCheckIn: false,
  },
]

const pastAppointments = [
  {
    id: 3,
    doctor: "Dr. Sarah Johnson",
    specialty: "Primary Care",
    date: "Dec 10, 2025",
    time: "9:00 AM",
    type: "In-Person",
    status: "Completed",
  },
  {
    id: 4,
    doctor: "Dr. Lisa Park",
    specialty: "Radiology",
    date: "Nov 28, 2025",
    time: "11:00 AM",
    type: "In-Person",
    status: "Completed",
  },
  {
    id: 5,
    doctor: "Dr. Michael Chen",
    specialty: "Cardiology",
    date: "Nov 15, 2025",
    time: "3:00 PM",
    type: "Video",
    status: "Completed",
  },
]

const doctors = [
  { name: "Dr. Sarah Johnson", specialty: "Primary Care" },
  { name: "Dr. Michael Chen", specialty: "Cardiology" },
  { name: "Dr. Lisa Park", specialty: "Radiology" },
  { name: "Dr. James Wilson", specialty: "Neurology" },
  { name: "Dr. Emily Davis", specialty: "Endocrinology" },
]

const timeSlots = ["9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"]

export default function PatientAppointments() {
  const [upcomingAppointments, setUpcomingAppointments] = useState(initialUpcomingAppointments)
  const [isScheduleOpen, setIsScheduleOpen] = useState(false)
  const [checkedInIds, setCheckedInIds] = useState<number[]>([])
  const [checkInSuccess, setCheckInSuccess] = useState<number | null>(null)

  // Schedule form state
  const [selectedDoctor, setSelectedDoctor] = useState("")
  const [selectedDate, setSelectedDate] = useState("")
  const [selectedTime, setSelectedTime] = useState("")
  const [appointmentType, setAppointmentType] = useState("")
  const [reason, setReason] = useState("")

  const handleCheckIn = (id: number) => {
    setCheckedInIds([...checkedInIds, id])
    setCheckInSuccess(id)
    setTimeout(() => setCheckInSuccess(null), 3000)
  }

  const handleSchedule = () => {
    if (!selectedDoctor || !selectedDate || !selectedTime || !appointmentType) return

    const doctor = doctors.find((d) => d.name === selectedDoctor)
    const newAppointment = {
      id: Date.now(),
      doctor: selectedDoctor,
      specialty: doctor?.specialty || "General",
      date: new Date(selectedDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      time: selectedTime,
      type: appointmentType,
      location: appointmentType === "Video" ? "Telehealth" : "Medical Center",
      canCheckIn: false,
    }

    setUpcomingAppointments([...upcomingAppointments, newAppointment])
    setIsScheduleOpen(false)
    setSelectedDoctor("")
    setSelectedDate("")
    setSelectedTime("")
    setAppointmentType("")
    setReason("")
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Appointments</h1>
          <p className="text-muted-foreground">Manage your upcoming and past appointments</p>
        </div>
        <Button onClick={() => setIsScheduleOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Schedule Appointment
        </Button>
      </div>

      {checkInSuccess && (
        <Alert className="bg-green-500/10 border-green-500/50">
          <Check className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700 dark:text-green-400">
            Successfully checked in! Please proceed to the waiting area.
          </AlertDescription>
        </Alert>
      )}

      {/* Upcoming Appointments */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Appointments</CardTitle>
          <CardDescription>Your scheduled visits</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {upcomingAppointments.map((apt) => (
            <div key={apt.id} className="flex items-center justify-between p-4 rounded-lg border bg-card">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  {apt.type === "Video" ? (
                    <Video className="h-5 w-5 text-primary" />
                  ) : (
                    <Calendar className="h-5 w-5 text-primary" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold">{apt.doctor}</h3>
                  <p className="text-sm text-muted-foreground">{apt.specialty}</p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {apt.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {apt.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" />
                      {apt.location}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={apt.type === "Video" ? "secondary" : "outline"}>{apt.type}</Badge>
                {checkedInIds.includes(apt.id) ? (
                  <Badge className="bg-green-600 hover:bg-green-600">Checked In</Badge>
                ) : (
                  <>
                    <Button variant="outline" size="sm">
                      Reschedule
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => (apt.type === "Video" ? window.open("#", "_blank") : handleCheckIn(apt.id))}
                    >
                      {apt.type === "Video" ? "Join Call" : "Check In"}
                    </Button>
                  </>
                )}
              </div>
            </div>
          ))}
          {upcomingAppointments.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No upcoming appointments. Click "Schedule Appointment" to book one.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Past Appointments */}
      <Card>
        <CardHeader>
          <CardTitle>Past Appointments</CardTitle>
          <CardDescription>Your appointment history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {pastAppointments.map((apt) => (
              <div key={apt.id} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-muted">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{apt.doctor}</p>
                    <p className="text-xs text-muted-foreground">
                      {apt.specialty} • {apt.date}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-green-600 hover:bg-green-600 text-white">{apt.status}</Badge>
                  <Button variant="ghost" size="sm">
                    View Summary
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isScheduleOpen} onOpenChange={setIsScheduleOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Schedule New Appointment</DialogTitle>
            <DialogDescription>Fill in the details to book your appointment</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Doctor</Label>
              <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a doctor" />
                </SelectTrigger>
                <SelectContent>
                  {doctors.map((doc) => (
                    <SelectItem key={doc.name} value={doc.name}>
                      {doc.name} - {doc.specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Appointment Type</Label>
              <Select value={appointmentType} onValueChange={setAppointmentType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="In-Person">In-Person Visit</SelectItem>
                  <SelectItem value="Video">Video Telehealth</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Time</Label>
                <Select value={selectedTime} onValueChange={setSelectedTime}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Reason for Visit (Optional)</Label>
              <Textarea
                placeholder="Describe your symptoms or reason for the appointment..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsScheduleOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSchedule}
              disabled={!selectedDoctor || !selectedDate || !selectedTime || !appointmentType}
            >
              Schedule Appointment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
