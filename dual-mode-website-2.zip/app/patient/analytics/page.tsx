"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Bar, BarChart } from "recharts"

const bloodPressureData = [
  { month: "Jul", systolic: 128, diastolic: 82 },
  { month: "Aug", systolic: 132, diastolic: 85 },
  { month: "Sep", systolic: 125, diastolic: 80 },
  { month: "Oct", systolic: 122, diastolic: 78 },
  { month: "Nov", systolic: 120, diastolic: 76 },
  { month: "Dec", systolic: 118, diastolic: 75 },
]

const cholesterolData = [
  { month: "Jul", ldl: 130, hdl: 45 },
  { month: "Aug", ldl: 125, hdl: 48 },
  { month: "Sep", ldl: 120, hdl: 50 },
  { month: "Oct", ldl: 115, hdl: 52 },
  { month: "Nov", ldl: 118, hdl: 51 },
  { month: "Dec", ldl: 112, hdl: 54 },
]

const glucoseData = [
  { month: "Jul", fasting: 102 },
  { month: "Aug", fasting: 98 },
  { month: "Sep", fasting: 95 },
  { month: "Oct", fasting: 92 },
  { month: "Nov", fasting: 94 },
  { month: "Dec", fasting: 90 },
]

export default function PatientAnalytics() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Health Analytics</h1>
        <p className="text-muted-foreground">Track your health metrics over time</p>
      </div>

      <Tabs defaultValue="blood-pressure" className="space-y-4">
        <TabsList>
          <TabsTrigger value="blood-pressure">Blood Pressure</TabsTrigger>
          <TabsTrigger value="cholesterol">Cholesterol</TabsTrigger>
          <TabsTrigger value="glucose">Blood Glucose</TabsTrigger>
        </TabsList>

        <TabsContent value="blood-pressure">
          <Card>
            <CardHeader>
              <CardTitle>Blood Pressure Trends</CardTitle>
              <CardDescription>Systolic and diastolic readings over the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  systolic: { label: "Systolic", color: "hsl(var(--chart-1))" },
                  diastolic: { label: "Diastolic", color: "hsl(var(--chart-2))" },
                }}
                className="h-[350px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={bloodPressureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[60, 150]} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line type="monotone" dataKey="systolic" stroke="var(--color-systolic)" strokeWidth={2} />
                    <Line type="monotone" dataKey="diastolic" stroke="var(--color-diastolic)" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
              <div className="mt-4 p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                <p className="text-sm font-medium text-green-700 dark:text-green-400">
                  Great progress! Your blood pressure has decreased by 10 mmHg over 6 months.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cholesterol">
          <Card>
            <CardHeader>
              <CardTitle>Cholesterol Levels</CardTitle>
              <CardDescription>LDL and HDL cholesterol over the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  ldl: { label: "LDL (Bad)", color: "hsl(var(--chart-5))" },
                  hdl: { label: "HDL (Good)", color: "hsl(var(--chart-3))" },
                }}
                className="h-[350px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={cholesterolData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="ldl" fill="var(--color-ldl)" radius={4} />
                    <Bar dataKey="hdl" fill="var(--color-hdl)" radius={4} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="glucose">
          <Card>
            <CardHeader>
              <CardTitle>Blood Glucose</CardTitle>
              <CardDescription>Fasting glucose levels over the past 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  fasting: { label: "Fasting Glucose", color: "hsl(var(--chart-4))" },
                }}
                className="h-[350px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={glucoseData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[70, 120]} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line type="monotone" dataKey="fasting" stroke="var(--color-fasting)" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
