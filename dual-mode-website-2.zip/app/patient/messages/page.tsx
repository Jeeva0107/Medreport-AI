"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Paperclip } from "lucide-react"

const conversations = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    role: "Primary Care",
    lastMessage: "Your lab results look good...",
    time: "2h ago",
    unread: true,
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    role: "Cardiologist",
    lastMessage: "Please continue with the current...",
    time: "1d ago",
    unread: true,
  },
  {
    id: 3,
    name: "Nurse Amy",
    role: "Care Coordinator",
    lastMessage: "Your appointment is confirmed",
    time: "2d ago",
    unread: false,
  },
]

const messages = [
  {
    id: 1,
    sender: "Dr. Sarah Johnson",
    content: "Hi John, I've reviewed your recent CBC results.",
    time: "10:30 AM",
    isDoctor: true,
  },
  { id: 2, sender: "You", content: "Thank you, Doctor. Is everything okay?", time: "10:35 AM", isDoctor: false },
  {
    id: 3,
    sender: "Dr. Sarah Johnson",
    content:
      "Your lab results look good overall. Your hemoglobin and white blood cell counts are within normal ranges. I noticed a slight elevation in your cholesterol, so I'd recommend scheduling a follow-up to discuss dietary changes.",
    time: "10:42 AM",
    isDoctor: true,
  },
  {
    id: 4,
    sender: "You",
    content: "I'll schedule that. Should I be concerned about the cholesterol?",
    time: "10:45 AM",
    isDoctor: false,
  },
  {
    id: 5,
    sender: "Dr. Sarah Johnson",
    content:
      "No need to worry - it's a minor elevation that can often be managed with lifestyle adjustments. We'll discuss a personalized plan during your follow-up.",
    time: "10:50 AM",
    isDoctor: true,
  },
]

export default function PatientMessages() {
  const [selectedConversation, setSelectedConversation] = useState(1)
  const [newMessage, setNewMessage] = useState("")

  return (
    <div className="p-6 h-[calc(100vh-3rem)]">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Messages</h1>
        <p className="text-muted-foreground">Communicate with your healthcare team</p>
      </div>

      <div className="grid grid-cols-3 gap-6 h-[calc(100%-5rem)]">
        {/* Conversations List */}
        <Card className="col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Conversations</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[500px]">
              {conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setSelectedConversation(conv.id)}
                  className={`w-full p-4 text-left border-b transition-colors hover:bg-muted/50 ${
                    selectedConversation === conv.id ? "bg-primary/5" : ""
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {conv.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-sm truncate">{conv.name}</p>
                        <span className="text-xs text-muted-foreground">{conv.time}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{conv.role}</p>
                      <p className="text-sm text-muted-foreground truncate mt-1">{conv.lastMessage}</p>
                    </div>
                    {conv.unread && <Badge className="h-2 w-2 p-0 rounded-full" />}
                  </div>
                </button>
              ))}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="col-span-2 flex flex-col">
          <CardHeader className="border-b pb-4">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-primary/10 text-primary">SJ</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-lg">Dr. Sarah Johnson</CardTitle>
                <CardDescription>Primary Care Physician</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col p-0">
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.isDoctor ? "justify-start" : "justify-end"}`}>
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${
                        msg.isDoctor ? "bg-muted" : "bg-primary text-primary-foreground"
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p
                        className={`text-xs mt-1 ${msg.isDoctor ? "text-muted-foreground" : "text-primary-foreground/70"}`}
                      >
                        {msg.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-4 border-t">
              <div className="flex gap-2">
                <Button variant="outline" size="icon">
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1"
                />
                <Button>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
