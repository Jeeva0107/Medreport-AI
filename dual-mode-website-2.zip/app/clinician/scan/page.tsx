"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Loader2,
  FileText,
  Scan,
  AlertCircle,
  Beaker,
  Radio,
  AlertTriangle,
  BookOpen,
  Upload,
  X,
  Shield,
  CheckCircle,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"

const labSampleReports = [
  { id: "cbc", name: "Complete Blood Count (CBC)" },
  { id: "lipid", name: "Lipid Panel" },
  { id: "metabolic", name: "Comprehensive Metabolic Panel" },
  { id: "thyroid", name: "Thyroid Function Test" },
  { id: "hemoglobin", name: "Hemoglobin A1C" },
]

const radiologySampleReports = [
  { id: "chest-xray", name: "Chest X-Ray" },
  { id: "brain-mri", name: "Brain MRI" },
  { id: "ct-abdomen", name: "CT Abdomen/Pelvis" },
  { id: "knee-mri", name: "Knee MRI" },
  { id: "spine-xray", name: "Lumbar Spine X-Ray" },
]

const sampleReportContent: Record<string, string> = {
  cbc: `COMPLETE BLOOD COUNT (CBC)
Patient: John Doe | DOB: 05/15/1980 | Date: 01/05/2026

White Blood Cells (WBC): 7.2 x10^9/L (Normal: 4.5-11.0)
Red Blood Cells (RBC): 4.8 x10^12/L (Normal: 4.5-5.5)
Hemoglobin: 11.2 g/dL (Normal: 13.5-17.5) [LOW]
Hematocrit: 34% (Normal: 38-50%) [LOW]
Platelet Count: 245 x10^9/L (Normal: 150-400)
MCV: 76 fL (Normal: 80-100) [LOW]
MCH: 29.6 pg (Normal: 27-33)
MCHC: 33.8 g/dL (Normal: 32-36)

INTERPRETATION: Microcytic anemia. Recommend iron studies.`,
  lipid: `LIPID PANEL
Patient: John Doe | DOB: 05/15/1980 | Date: 01/03/2026

Total Cholesterol: 245 mg/dL (Desirable: <200) [HIGH]
LDL Cholesterol: 168 mg/dL (Optimal: <100) [HIGH]
HDL Cholesterol: 38 mg/dL (Normal: >40) [LOW]
Triglycerides: 195 mg/dL (Normal: <150) [HIGH]
VLDL: 39 mg/dL (Normal: 5-40)

INTERPRETATION: Significant dyslipidemia. High cardiovascular risk.`,
  metabolic: `COMPREHENSIVE METABOLIC PANEL (CMP)
Patient: John Doe | DOB: 05/15/1980 | Date: 01/04/2026

Glucose: 126 mg/dL (Normal: 70-100) [HIGH]
BUN: 28 mg/dL (Normal: 7-20) [HIGH]
Creatinine: 1.5 mg/dL (Normal: 0.7-1.3) [HIGH]
Sodium: 140 mEq/L (Normal: 136-145)
Potassium: 5.2 mEq/L (Normal: 3.5-5.0) [HIGH]
eGFR: 52 mL/min/1.73m2 (Normal: >60) [LOW]

INTERPRETATION: Elevated glucose, impaired renal function (CKD Stage 3a).`,
  thyroid: `THYROID FUNCTION TEST
Patient: John Doe | DOB: 05/15/1980 | Date: 01/02/2026

TSH: 8.5 mIU/L (Normal: 0.4-4.0) [HIGH]
Free T4: 0.7 ng/dL (Normal: 0.8-1.8) [LOW]
Free T3: 2.0 pg/mL (Normal: 2.3-4.2) [LOW]

INTERPRETATION: Primary hypothyroidism.`,
  hemoglobin: `HEMOGLOBIN A1C TEST
Patient: John Doe | DOB: 05/15/1980 | Date: 01/01/2026

Hemoglobin A1C: 7.2% (Normal: <5.7%, Prediabetes: 5.7-6.4%, Diabetes: ≥6.5%) [HIGH]

INTERPRETATION: Diabetes with suboptimal glycemic control.`,
  "chest-xray": `CHEST X-RAY (PA AND LATERAL)
Patient: John Doe | DOB: 05/15/1980 | Date: 12/28/2025

FINDINGS:
- Cardiomegaly with cardiothoracic ratio of 0.58 (>0.5)
- Bilateral interstitial markings, possible early pulmonary edema
- Small bilateral pleural effusions
- No pneumothorax
- Atherosclerotic calcification of the aortic knob

IMPRESSION: Cardiomegaly with findings suggestive of heart failure.`,
  "brain-mri": `BRAIN MRI WITHOUT CONTRAST
Patient: John Doe | DOB: 05/15/1980 | Date: 12/15/2025

TECHNIQUE: Multiplanar, multisequence MRI of the brain without IV contrast.

FINDINGS:
- No acute intracranial hemorrhage
- No mass effect or midline shift
- Multiple T2/FLAIR hyperintense foci in periventricular white matter
- Fazekas Grade 2 small vessel ischemic changes
- Mild generalized cerebral atrophy
- No restricted diffusion

IMPRESSION: Chronic small vessel ischemic disease. No acute abnormality.`,
  "ct-abdomen": `CT ABDOMEN AND PELVIS WITH CONTRAST
Patient: John Doe | DOB: 05/15/1980 | Date: 12/20/2025

FINDINGS:
- Liver: Hepatic steatosis (fatty liver)
- Spleen: Mildly enlarged at 14cm
- Kidneys: Bilateral cortical thinning, multiple simple cysts
- Aorta: Moderate atherosclerotic calcification
- Incidental finding: 1.2cm adrenal nodule, left

IMPRESSION: Hepatic steatosis, splenomegaly, changes consistent with CKD.
Follow-up recommended for adrenal nodule.`,
  "knee-mri": `MRI RIGHT KNEE WITHOUT CONTRAST
Patient: John Doe | DOB: 05/15/1980 | Date: 12/10/2025

FINDINGS:
- ACL: Intact
- PCL: Intact  
- Medial meniscus: Grade 2 signal, horizontal tear posterior horn
- Lateral meniscus: Intact
- Moderate joint effusion
- Grade 3 chondromalacia medial femoral condyle
- Subchondral edema medial tibial plateau

IMPRESSION: Medial meniscus tear with moderate osteoarthritic changes.`,
  "spine-xray": `LUMBAR SPINE X-RAY
Patient: John Doe | DOB: 05/15/1980 | Date: 12/05/2025

FINDINGS:
- Moderate disc space narrowing at L4-L5 and L5-S1
- Anterior osteophytes L3-L5
- Grade 1 anterolisthesis L4 on L5
- Facet joint hypertrophy L4-L5
- Sacroiliac joints are normal

IMPRESSION: Degenerative disc disease with spondylolisthesis L4-L5.`,
}

export default function ClinicianScan() {
  const [reportType, setReportType] = useState<"lab" | "radiology">("lab")
  const [reportText, setReportText] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<any>(null)
  const [attachedFile, setAttachedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleSampleSelect = (reportId: string) => {
    setReportText(sampleReportContent[reportId] || "")
    setAnalysis(null)
    setAttachedFile(null)
  }

  const handleFileAttach = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAttachedFile(file)
      if (file.type === "text/plain" || file.name.endsWith(".txt")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setReportText(e.target?.result as string)
        }
        reader.readAsText(file)
      }
    }
  }

  const handleAnalyze = async () => {
    if (!reportText.trim()) return

    setIsAnalyzing(true)
    setAnalysis(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          report: reportText,
          mode: "clinician",
          reportType: reportType,
        }),
      })

      if (!response.ok) throw new Error("Analysis failed")

      const data = await response.json()
      setAnalysis(data)
    } catch (error) {
      console.error("Analysis error:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const renderInputCard = (type: "lab" | "radiology") => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {type === "lab" ? <Beaker className="h-5 w-5 text-accent" /> : <Radio className="h-5 w-5 text-accent" />}
          {type === "lab" ? "Lab Report Input" : "Radiology Report Input"}
        </CardTitle>
        <CardDescription>
          {type === "lab"
            ? "Paste lab results, select sample, or attach file"
            : "Paste imaging report, select sample, or attach file"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Select onValueChange={handleSampleSelect}>
          <SelectTrigger>
            <SelectValue placeholder="Load sample report" />
          </SelectTrigger>
          <SelectContent>
            {(type === "lab" ? labSampleReports : radiologySampleReports).map((report) => (
              <SelectItem key={report.id} value={report.id}>
                {report.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileAttach}
            accept=".txt,.pdf,.doc,.docx"
            className="hidden"
          />
          <Button variant="outline" className="flex-1 bg-transparent" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-4 w-4 mr-2" />
            Attach Report
          </Button>
        </div>

        {attachedFile && (
          <div className="flex items-center gap-2 p-2 rounded-lg bg-muted">
            <FileText className="h-4 w-4 text-accent" />
            <span className="text-sm flex-1 truncate">{attachedFile.name}</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => {
                setAttachedFile(null)
                if (fileInputRef.current) fileInputRef.current.value = ""
              }}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        )}

        <Textarea
          placeholder={type === "lab" ? "Paste lab report..." : "Paste radiology report..."}
          value={reportText}
          onChange={(e) => setReportText(e.target.value)}
          className="min-h-[250px] font-mono text-sm"
        />
        <Button onClick={handleAnalyze} disabled={!reportText.trim() || isAnalyzing} className="w-full">
          {isAnalyzing ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Scan className="h-4 w-4 mr-2" />
              Analyze Report
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )

  const renderResultsCard = () => (
    <Card>
      <CardHeader>
        <CardTitle>Clinical Analysis</CardTitle>
        <CardDescription>AI-generated clinical interpretation with guideline references</CardDescription>
      </CardHeader>
      <CardContent>
        {!analysis && !isAnalyzing && (
          <div className="flex flex-col items-center justify-center h-[300px] text-center text-muted-foreground">
            <FileText className="h-12 w-12 mb-4 opacity-50" />
            <p>Load a report and analyze for clinical insights</p>
          </div>
        )}
        {isAnalyzing && (
          <div className="flex flex-col items-center justify-center h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-accent mb-4" />
            <p className="text-muted-foreground">Performing clinical analysis...</p>
          </div>
        )}
        {analysis && (
          <div className="space-y-4">
            {/* Clinical Impression / Bullet Summary */}
            <div className="p-4 rounded-lg bg-accent/5 border border-accent/20">
              <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-accent" />
                Clinical Impression (Bullet Summary)
              </h4>
              <p className="text-sm leading-relaxed">{analysis.clinicalImpression}</p>
            </div>

            {/* Critical Values Table */}
            {analysis.criticalValues && analysis.criticalValues.length > 0 && (
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2 text-destructive">
                  <AlertTriangle className="h-4 w-4" />
                  Critical/Abnormal Values
                </h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Parameter</TableHead>
                      <TableHead className="text-xs">Value</TableHead>
                      <TableHead className="text-xs">Reference</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {analysis.criticalValues.map((cv: any, i: number) => (
                      <TableRow key={i}>
                        <TableCell className="text-sm font-medium">{cv.parameter}</TableCell>
                        <TableCell className="text-sm text-destructive font-medium">{cv.value}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{cv.reference}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            {/* Likely Implications / Differentials */}
            {analysis.differentials && (
              <div className="p-4 rounded-lg bg-muted">
                <h4 className="font-semibold text-sm mb-2">Likely Implications & Differential Considerations</h4>
                <ul className="space-y-2 text-sm">
                  {analysis.differentials.map((d: string, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5 shrink-0">
                        {i + 1}
                      </Badge>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Suggested Next Steps (Non-Prescriptive) */}
            {analysis.suggestedActions && (
              <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
                <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-primary" />
                  Suggested Next Steps (Non-Prescriptive)
                </h4>
                <ul className="space-y-1.5 text-sm">
                  {analysis.suggestedActions.map((a: string, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-primary font-bold">→</span>
                      <span>{a}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Guidelines Reference */}
            {analysis.guidelines && (
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <h4 className="font-semibold text-xs mb-1 flex items-center gap-1 text-blue-700 dark:text-blue-400">
                  <BookOpen className="h-3 w-3" />
                  Relevant Guidelines & Citations
                </h4>
                <p className="text-xs text-muted-foreground">{analysis.guidelines}</p>
              </div>
            )}

            {/* Safety Disclaimer */}
            <div className="p-3 rounded-lg bg-muted/50 border">
              <h4 className="font-semibold text-xs mb-1 flex items-center gap-1 text-muted-foreground">
                <Shield className="h-3 w-3" />
                Clinical Decision Support Notice
              </h4>
              <p className="text-xs text-muted-foreground">
                This is AI-assisted analysis using synthetic data only. Not a medical diagnosis. All insights should be
                verified against clinical judgment and current guidelines. Escalate red flags immediately.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Report Analysis</h1>
        <p className="text-muted-foreground">AI-assisted clinical report interpretation with guideline references</p>
      </div>

      <Alert variant="default" className="border-accent/50 bg-accent/5">
        <AlertCircle className="h-4 w-4 text-accent" />
        <AlertDescription className="text-accent-foreground">
          Clinical decision support tool using synthetic/de-identified data. All AI-generated insights should be
          verified against clinical judgment and current guidelines. Not a medical diagnosis.
        </AlertDescription>
      </Alert>

      <Tabs
        value={reportType}
        onValueChange={(v) => {
          setReportType(v as "lab" | "radiology")
          setAnalysis(null)
        }}
      >
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="lab" className="gap-2">
            <Beaker className="h-4 w-4" />
            Lab Reports
          </TabsTrigger>
          <TabsTrigger value="radiology" className="gap-2">
            <Radio className="h-4 w-4" />
            Radiology Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lab" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {renderInputCard("lab")}
            {renderResultsCard()}
          </div>
        </TabsContent>

        <TabsContent value="radiology" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {renderInputCard("radiology")}
            {renderResultsCard()}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
