"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, User, FileText, Calendar, Pill, Plus, Save, X } from "lucide-react"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const patients = [
  {
    id: 1,
    name: "John Doe",
    age: 45,
    mrn: "MRN-001234",
    lastVisit: "Dec 15, 2025",
    conditions: ["Hypertension", "Hyperlipidemia"],
    status: "Active",
  },
  {
    id: 2,
    name: "Sarah Wilson",
    age: 32,
    mrn: "MRN-001235",
    lastVisit: "Nov 28, 2025",
    conditions: ["Asthma"],
    status: "Active",
  },
  {
    id: 3,
    name: "Michael Brown",
    age: 58,
    mrn: "MRN-001236",
    lastVisit: "Dec 20, 2025",
    conditions: ["Type 2 Diabetes", "Obesity"],
    status: "Active",
  },
  {
    id: 4,
    name: "Emily Davis",
    age: 29,
    mrn: "MRN-001237",
    lastVisit: "Jan 2, 2026",
    conditions: ["Anxiety", "Migraine"],
    status: "Active",
  },
  {
    id: 5,
    name: "Robert Chen",
    age: 67,
    mrn: "MRN-001238",
    lastVisit: "Dec 10, 2025",
    conditions: ["CHF", "Atrial Fibrillation", "CKD Stage 3"],
    status: "Active",
  },
]

const patientDetails: Record<number, any> = {
  1: {
    demographics: {
      dob: "05/15/1980",
      gender: "Male",
      phone: "(555) 123-4567",
      email: "john.doe@email.com",
      address: "123 Main St, City, State 12345",
    },
    vitals: [
      { date: "Dec 15, 2025", bp: "138/88", hr: "72", temp: "98.6", weight: "185" },
      { date: "Nov 10, 2025", bp: "142/90", hr: "76", temp: "98.4", weight: "187" },
      { date: "Oct 5, 2025", bp: "145/92", hr: "78", temp: "98.6", weight: "189" },
    ],
    medications: [
      { name: "Lisinopril 10mg", frequency: "Once daily", startDate: "Jan 2024" },
      { name: "Atorvastatin 20mg", frequency: "Once daily at bedtime", startDate: "Mar 2024" },
      { name: "Aspirin 81mg", frequency: "Once daily", startDate: "Jan 2024" },
    ],
    allergies: ["Penicillin", "Sulfa drugs"],
    visits: [
      {
        date: "Dec 15, 2025",
        type: "Follow-up",
        provider: "Dr. Smith",
        notes: "BP improving with medication. Continue current regimen.",
      },
      {
        date: "Nov 10, 2025",
        type: "Follow-up",
        provider: "Dr. Smith",
        notes: "Increased Lisinopril from 5mg to 10mg.",
      },
      {
        date: "Oct 5, 2025",
        type: "Annual Wellness",
        provider: "Dr. Smith",
        notes: "Started statin therapy for elevated LDL.",
      },
    ],
    notes: [
      {
        date: "Dec 15, 2025",
        author: "Dr. Smith",
        content: "Patient reports improved compliance with low-sodium diet.",
      },
      { date: "Nov 10, 2025", author: "Nurse Johnson", content: "Patient educated on home BP monitoring." },
    ],
  },
}

export default function PatientHistory() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)
  const [isAddingNote, setIsAddingNote] = useState(false)
  const [newNoteType, setNewNoteType] = useState("")
  const [newNoteContent, setNewNoteContent] = useState("")
  const [patientNotes, setPatientNotes] = useState<Record<number, any[]>>({
    1: patientDetails[1]?.notes || [],
  })

  const filteredPatients = patients.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.mrn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.conditions.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const handleViewPatient = (patient: any) => {
    setSelectedPatient(patient)
    setIsDetailOpen(true)
  }

  const handleSaveNote = () => {
    if (!newNoteContent.trim() || !selectedPatient) return

    const newNote = {
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      author: "Dr. Current User",
      type: newNoteType,
      content: newNoteContent,
    }

    setPatientNotes((prev) => ({
      ...prev,
      [selectedPatient.id]: [newNote, ...(prev[selectedPatient.id] || [])],
    }))

    setIsAddingNote(false)
    setNewNoteType("")
    setNewNoteContent("")
  }

  const currentPatientNotes = selectedPatient
    ? patientNotes[selectedPatient.id] || patientDetails[selectedPatient.id]?.notes || []
    : []

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Patient History</h1>
        <p className="text-muted-foreground">Search and view patient records</p>
      </div>

      <div className="relative max-w-xl">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, MRN, or condition..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Patient List</CardTitle>
          <CardDescription>{filteredPatients.length} patients found</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredPatients.map((patient) => (
              <div
                key={patient.id}
                className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => handleViewPatient(patient)}
              >
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-accent/10 text-accent">
                      {patient.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{patient.name}</p>
                      <span className="text-sm text-muted-foreground">({patient.age}y)</span>
                      <Badge variant="outline" className="text-xs">
                        {patient.mrn}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {patient.conditions.map((condition, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">
                          {condition}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Last visit: {patient.lastVisit}</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <FileText className="h-4 w-4 mr-2" />
                  View Record
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Sheet open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <SheetContent className="w-[600px] sm:w-[700px] overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              {selectedPatient?.name}
            </SheetTitle>
            <SheetDescription>
              {selectedPatient?.mrn} • {selectedPatient?.age} years old
            </SheetDescription>
          </SheetHeader>

          {selectedPatient && (
            <Tabs defaultValue="overview" className="mt-6">
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="vitals">Vitals</TabsTrigger>
                <TabsTrigger value="medications">Meds</TabsTrigger>
                <TabsTrigger value="notes">Notes</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-4 space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Demographics
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-sm p-3 rounded-lg bg-muted">
                    <div>
                      <span className="text-muted-foreground">DOB:</span> {patientDetails[1]?.demographics.dob}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Gender:</span> {patientDetails[1]?.demographics.gender}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Phone:</span> {patientDetails[1]?.demographics.phone}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Email:</span> {patientDetails[1]?.demographics.email}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2">Active Conditions</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedPatient.conditions.map((c: string, i: number) => (
                      <Badge key={i} variant="outline">
                        {c}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2">Allergies</h4>
                  <div className="flex flex-wrap gap-2">
                    {patientDetails[1]?.allergies.map((a: string, i: number) => (
                      <Badge key={i} variant="destructive">
                        {a}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Recent Visits
                  </h4>
                  <div className="space-y-2">
                    {patientDetails[1]?.visits.map((visit: any, i: number) => (
                      <div key={i} className="p-3 rounded-lg bg-muted text-sm">
                        <div className="flex justify-between mb-1">
                          <span className="font-medium">{visit.type}</span>
                          <span className="text-muted-foreground">{visit.date}</span>
                        </div>
                        <p className="text-muted-foreground text-xs">{visit.provider}</p>
                        <p className="mt-1">{visit.notes}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="vitals" className="mt-4">
                <div className="space-y-3">
                  {patientDetails[1]?.vitals.map((v: any, i: number) => (
                    <div key={i} className="p-3 rounded-lg border">
                      <p className="text-sm font-medium mb-2">{v.date}</p>
                      <div className="grid grid-cols-4 gap-2 text-center">
                        <div className="p-2 rounded bg-muted">
                          <p className="text-xs text-muted-foreground">BP</p>
                          <p className="font-medium">{v.bp}</p>
                        </div>
                        <div className="p-2 rounded bg-muted">
                          <p className="text-xs text-muted-foreground">HR</p>
                          <p className="font-medium">{v.hr}</p>
                        </div>
                        <div className="p-2 rounded bg-muted">
                          <p className="text-xs text-muted-foreground">Temp</p>
                          <p className="font-medium">{v.temp}°F</p>
                        </div>
                        <div className="p-2 rounded bg-muted">
                          <p className="text-xs text-muted-foreground">Weight</p>
                          <p className="font-medium">{v.weight} lbs</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="medications" className="mt-4">
                <div className="space-y-2">
                  {patientDetails[1]?.medications.map((med: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                      <div>
                        <p className="font-medium flex items-center gap-2">
                          <Pill className="h-4 w-4 text-primary" />
                          {med.name}
                        </p>
                        <p className="text-sm text-muted-foreground">{med.frequency}</p>
                      </div>
                      <Badge variant="outline">Since {med.startDate}</Badge>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="notes" className="mt-4 space-y-4">
                {!isAddingNote ? (
                  <Button onClick={() => setIsAddingNote(true)} className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Note
                  </Button>
                ) : (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">New Note</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label>Note Type</Label>
                        <Select value={newNoteType} onValueChange={setNewNoteType}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Progress Note">Progress Note</SelectItem>
                            <SelectItem value="Phone Call">Phone Call</SelectItem>
                            <SelectItem value="Lab Review">Lab Review</SelectItem>
                            <SelectItem value="Referral">Referral</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Note Content</Label>
                        <Textarea
                          placeholder="Enter note details..."
                          value={newNoteContent}
                          onChange={(e) => setNewNoteContent(e.target.value)}
                          rows={4}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={handleSaveNote} disabled={!newNoteContent.trim()}>
                          <Save className="h-4 w-4 mr-2" />
                          Save Note
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsAddingNote(false)
                            setNewNoteContent("")
                            setNewNoteType("")
                          }}
                        >
                          <X className="h-4 w-4 mr-2" />
                          Cancel
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="space-y-2">
                  {currentPatientNotes.map((note: any, i: number) => (
                    <div key={i} className="p-3 rounded-lg border">
                      <div className="flex justify-between mb-1">
                        <span className="font-medium text-sm">{note.author}</span>
                        <span className="text-xs text-muted-foreground">{note.date}</span>
                      </div>
                      {note.type && (
                        <Badge variant="outline" className="mb-2 text-xs">
                          {note.type}
                        </Badge>
                      )}
                      <p className="text-sm">{note.content}</p>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}
