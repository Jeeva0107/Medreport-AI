"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Search, Video, MapPin, User } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"

const appointments = [
  {
    id: 1,
    time: "9:00 AM",
    patient: "John Doe",
    age: 45,
    type: "Follow-up",
    reason: "Hypertension management",
    status: "Checked In",
    mode: "In-Person",
    mrn: "MRN-001234",
  },
  {
    id: 2,
    time: "9:30 AM",
    patient: "Sarah Wilson",
    age: 32,
    type: "New Patient",
    reason: "Annual wellness exam",
    status: "Upcoming",
    mode: "In-Person",
    mrn: "MRN-001235",
  },
  {
    id: 3,
    time: "10:00 AM",
    patient: "Michael Brown",
    age: 58,
    type: "Follow-up",
    reason: "Diabetes review",
    status: "Upcoming",
    mode: "Telehealth",
    mrn: "MRN-001236",
  },
  {
    id: 4,
    time: "10:30 AM",
    patient: "Emily Davis",
    age: 29,
    type: "Urgent",
    reason: "Chest pain evaluation",
    status: "Upcoming",
    mode: "In-Person",
    mrn: "MRN-001237",
  },
  {
    id: 5,
    time: "11:00 AM",
    patient: "Robert Chen",
    age: 67,
    type: "Follow-up",
    reason: "Post-procedure check",
    status: "Upcoming",
    mode: "Telehealth",
    mrn: "MRN-001238",
  },
  {
    id: 6,
    time: "11:30 AM",
    patient: "Maria Garcia",
    age: 41,
    type: "Follow-up",
    reason: "Medication adjustment",
    status: "Upcoming",
    mode: "In-Person",
    mrn: "MRN-001239",
  },
  {
    id: 7,
    time: "1:00 PM",
    patient: "James Lee",
    age: 53,
    type: "New Patient",
    reason: "Referral - cardiac",
    status: "Upcoming",
    mode: "In-Person",
    mrn: "MRN-001240",
  },
  {
    id: 8,
    time: "1:30 PM",
    patient: "Linda Martinez",
    age: 36,
    type: "Follow-up",
    reason: "Lab review",
    status: "Upcoming",
    mode: "Telehealth",
    mrn: "MRN-001241",
  },
]

const mockPatientChart = {
  demographics: {
    name: "John Doe",
    dob: "05/15/1980",
    age: 45,
    gender: "Male",
    mrn: "MRN-001234",
    phone: "(555) 123-4567",
    address: "123 Main St, City, State 12345",
  },
  vitals: {
    bp: "138/88 mmHg",
    hr: "72 bpm",
    temp: "98.6°F",
    weight: "185 lbs",
    height: "5'10\"",
    bmi: "26.5",
  },
  conditions: ["Hypertension", "Hyperlipidemia", "Obesity"],
  medications: [
    { name: "Lisinopril 10mg", frequency: "Once daily" },
    { name: "Atorvastatin 20mg", frequency: "Once daily at bedtime" },
  ],
  allergies: ["Penicillin", "Sulfa drugs"],
  recentLabs: [
    { test: "CBC", date: "12/15/2025", status: "Normal" },
    { test: "Lipid Panel", date: "12/15/2025", status: "Abnormal" },
    { test: "CMP", date: "12/15/2025", status: "Normal" },
  ],
}

const calendarEvents = [
  { date: "Jan 7", count: 8 },
  { date: "Jan 8", count: 6 },
  { date: "Jan 9", count: 7 },
  { date: "Jan 10", count: 5 },
  { date: "Jan 13", count: 8 },
  { date: "Jan 14", count: 6 },
  { date: "Jan 15", count: 7 },
]

export default function ClinicianAppointments() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [isChartOpen, setIsChartOpen] = useState(false)
  const [isCalendarOpen, setIsCalendarOpen] = useState(false)
  const [activeVisit, setActiveVisit] = useState<number | null>(null)

  const filteredAppointments = appointments.filter(
    (apt) =>
      apt.patient.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.reason.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleStartVisit = (apt: any) => {
    setActiveVisit(apt.id)
    setSelectedPatient(apt)
  }

  const handleViewChart = (apt: any) => {
    setSelectedPatient(apt)
    setIsChartOpen(true)
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Booked Appointments</h1>
          <p className="text-muted-foreground">Manage your scheduled patient appointments</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setIsCalendarOpen(true)}>
            <Calendar className="h-4 w-4 mr-2" />
            View Calendar
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search patients or reasons..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="today">
        <TabsList>
          <TabsTrigger value="today">Today (8)</TabsTrigger>
          <TabsTrigger value="tomorrow">Tomorrow (6)</TabsTrigger>
          <TabsTrigger value="week">This Week (24)</TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>January 7, 2026</CardTitle>
              <CardDescription>8 appointments scheduled</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {filteredAppointments.map((apt) => (
                <div
                  key={apt.id}
                  className={`flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors ${
                    activeVisit === apt.id ? "ring-2 ring-primary bg-primary/5" : ""
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className="text-center min-w-[70px]">
                      <p className="font-semibold">{apt.time}</p>
                      <p className="text-xs text-muted-foreground">30 min</p>
                    </div>
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-accent/10 text-accent">
                        {apt.patient
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{apt.patient}</p>
                        <span className="text-sm text-muted-foreground">({apt.age}y)</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{apt.reason}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {apt.type}
                        </Badge>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          {apt.mode === "Telehealth" ? <Video className="h-3 w-3" /> : <MapPin className="h-3 w-3" />}
                          {apt.mode}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      className={
                        apt.status === "Checked In"
                          ? "bg-green-600 hover:bg-green-600 text-white"
                          : apt.type === "Urgent"
                            ? "bg-destructive hover:bg-destructive"
                            : ""
                      }
                      variant={
                        apt.status === "Checked In" ? "default" : apt.type === "Urgent" ? "destructive" : "secondary"
                      }
                    >
                      {apt.status}
                    </Badge>
                    <Button variant="outline" size="sm" onClick={() => handleViewChart(apt)}>
                      View Chart
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleStartVisit(apt)}
                      variant={activeVisit === apt.id ? "secondary" : "default"}
                    >
                      {activeVisit === apt.id
                        ? "In Progress"
                        : apt.mode === "Telehealth"
                          ? "Start Call"
                          : "Start Visit"}
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tomorrow">
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              6 appointments scheduled for tomorrow
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="week">
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              24 appointments scheduled this week
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Sheet open={isChartOpen} onOpenChange={setIsChartOpen}>
        <SheetContent className="w-[500px] sm:w-[600px] overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Patient Chart
            </SheetTitle>
            <SheetDescription>
              {selectedPatient?.patient} - {selectedPatient?.mrn}
            </SheetDescription>
          </SheetHeader>
          <div className="mt-6 space-y-6">
            {/* Demographics */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Demographics</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-muted-foreground">DOB:</span> {mockPatientChart.demographics.dob}
                </div>
                <div>
                  <span className="text-muted-foreground">Age:</span> {mockPatientChart.demographics.age}y
                </div>
                <div>
                  <span className="text-muted-foreground">Gender:</span> {mockPatientChart.demographics.gender}
                </div>
                <div>
                  <span className="text-muted-foreground">Phone:</span> {mockPatientChart.demographics.phone}
                </div>
              </div>
            </div>

            {/* Vitals */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Latest Vitals</h4>
              <div className="grid grid-cols-3 gap-2">
                {Object.entries(mockPatientChart.vitals).map(([key, value]) => (
                  <div key={key} className="p-2 rounded bg-muted text-center">
                    <p className="text-xs text-muted-foreground uppercase">{key}</p>
                    <p className="font-medium text-sm">{value}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Conditions */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Active Conditions</h4>
              <div className="flex flex-wrap gap-2">
                {mockPatientChart.conditions.map((c, i) => (
                  <Badge key={i} variant="outline">
                    {c}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Medications */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Current Medications</h4>
              <div className="space-y-2">
                {mockPatientChart.medications.map((med, i) => (
                  <div key={i} className="p-2 rounded bg-muted text-sm">
                    <p className="font-medium">{med.name}</p>
                    <p className="text-xs text-muted-foreground">{med.frequency}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Allergies */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Allergies</h4>
              <div className="flex flex-wrap gap-2">
                {mockPatientChart.allergies.map((a, i) => (
                  <Badge key={i} variant="destructive">
                    {a}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Recent Labs */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Recent Labs</h4>
              <div className="space-y-2">
                {mockPatientChart.recentLabs.map((lab, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded bg-muted text-sm">
                    <div>
                      <p className="font-medium">{lab.test}</p>
                      <p className="text-xs text-muted-foreground">{lab.date}</p>
                    </div>
                    <Badge variant={lab.status === "Normal" ? "secondary" : "destructive"}>{lab.status}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <Dialog open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Appointment Calendar</DialogTitle>
            <DialogDescription>View your upcoming schedule</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="grid grid-cols-7 gap-2 text-center text-sm mb-4">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="font-medium text-muted-foreground">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-2">
              {calendarEvents.map((event, i) => (
                <div
                  key={i}
                  className="aspect-square flex flex-col items-center justify-center rounded-lg border hover:bg-muted cursor-pointer"
                >
                  <span className="text-sm font-medium">{event.date.split(" ")[1]}</span>
                  <Badge variant="secondary" className="mt-1 text-xs">
                    {event.count}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
