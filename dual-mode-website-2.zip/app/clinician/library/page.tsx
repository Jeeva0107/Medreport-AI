"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, BookOpen, FileText, ExternalLink, Star, Calculator, Pill, AlertCircle } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"

const guidelines = [
  {
    id: 1,
    title: "JNC 8 Hypertension Guidelines",
    source: "JAMA",
    year: "2024",
    category: "Cardiology",
    starred: true,
    url: "https://jamanetwork.com",
    summary:
      "Evidence-based guideline for the management of high blood pressure in adults. Recommends BP targets and first-line medications.",
  },
  {
    id: 2,
    title: "ADA Standards of Diabetes Care",
    source: "ADA",
    year: "2025",
    category: "Endocrinology",
    starred: true,
    url: "https://diabetes.org",
    summary:
      "Comprehensive standards for diabetes management including A1C targets, medication selection, and screening recommendations.",
  },
  {
    id: 3,
    title: "ACC/AHA Cholesterol Guidelines",
    source: "ACC/AHA",
    year: "2023",
    category: "Cardiology",
    starred: false,
    url: "https://acc.org",
    summary: "Guidelines for assessment and treatment of blood cholesterol to reduce cardiovascular risk.",
  },
  {
    id: 4,
    title: "GOLD COPD Guidelines",
    source: "GOLD",
    year: "2024",
    category: "Pulmonology",
    starred: false,
    url: "https://goldcopd.org",
    summary: "Global strategy for diagnosis, management, and prevention of COPD.",
  },
  {
    id: 5,
    title: "ACR Appropriateness Criteria",
    source: "ACR",
    year: "2024",
    category: "Radiology",
    starred: true,
    url: "https://acr.org",
    summary: "Evidence-based guidelines for imaging studies across various clinical conditions.",
  },
  {
    id: 6,
    title: "USPSTF Cancer Screening",
    source: "USPSTF",
    year: "2024",
    category: "Preventive",
    starred: false,
    url: "https://uspreventiveservicestaskforce.org",
    summary: "Recommendations for cancer screening including breast, colorectal, lung, and cervical cancer.",
  },
]

const drugReferences = [
  {
    name: "Lisinopril",
    class: "ACE Inhibitor",
    indication: "Hypertension, Heart Failure",
    dosing: "5-40mg daily",
    contraindications: "Pregnancy, Angioedema history",
  },
  {
    name: "Metformin",
    class: "Biguanide",
    indication: "Type 2 Diabetes",
    dosing: "500-2000mg daily in divided doses",
    contraindications: "eGFR <30, Acute kidney injury",
  },
  {
    name: "Atorvastatin",
    class: "Statin",
    indication: "Hyperlipidemia",
    dosing: "10-80mg daily",
    contraindications: "Active liver disease, Pregnancy",
  },
  {
    name: "Amlodipine",
    class: "CCB",
    indication: "Hypertension, Angina",
    dosing: "2.5-10mg daily",
    contraindications: "Severe aortic stenosis",
  },
  {
    name: "Omeprazole",
    class: "PPI",
    indication: "GERD, Peptic Ulcer",
    dosing: "20-40mg daily",
    contraindications: "Hypersensitivity to PPIs",
  },
  {
    name: "Levothyroxine",
    class: "Thyroid Hormone",
    indication: "Hypothyroidism",
    dosing: "25-200mcg daily",
    contraindications: "Untreated adrenal insufficiency",
  },
]

const calculators = [
  {
    name: "CHA2DS2-VASc Score",
    description: "Stroke risk in atrial fibrillation",
    inputs: ["CHF", "Hypertension", "Age", "Diabetes", "Stroke/TIA", "Vascular disease", "Sex"],
  },
  {
    name: "ASCVD Risk Calculator",
    description: "10-year cardiovascular risk",
    inputs: ["Age", "Sex", "Race", "Total Cholesterol", "HDL", "Systolic BP", "Diabetes", "Smoker"],
  },
  {
    name: "GFR Calculator",
    description: "Estimated glomerular filtration rate",
    inputs: ["Creatinine", "Age", "Sex", "Race"],
  },
  { name: "BMI Calculator", description: "Body mass index", inputs: ["Weight", "Height"] },
  {
    name: "Creatinine Clearance",
    description: "Cockcroft-Gault equation",
    inputs: ["Age", "Weight", "Sex", "Creatinine"],
  },
  {
    name: "MELD Score",
    description: "Liver disease severity",
    inputs: ["Bilirubin", "INR", "Creatinine", "Sodium", "Dialysis"],
  },
]

export default function MedicalLibrary() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedGuideline, setSelectedGuideline] = useState<any>(null)
  const [selectedDrug, setSelectedDrug] = useState<any>(null)
  const [selectedCalculator, setSelectedCalculator] = useState<any>(null)
  const [calculatorResult, setCalculatorResult] = useState<string | null>(null)
  const [starredGuidelines, setStarredGuidelines] = useState<number[]>(
    guidelines.filter((g) => g.starred).map((g) => g.id),
  )

  const filteredGuidelines = guidelines.filter(
    (g) =>
      g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredDrugs = drugReferences.filter(
    (d) =>
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.class.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.indication.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredCalculators = calculators.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const toggleStar = (id: number) => {
    setStarredGuidelines((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  const runCalculator = (calcName: string) => {
    const results: Record<string, string> = {
      "CHA2DS2-VASc Score": "Score: 2 - Moderate risk (2.2% annual stroke risk). Consider anticoagulation.",
      "ASCVD Risk Calculator": "10-year ASCVD Risk: 7.5% - Intermediate risk. Discuss statin therapy.",
      "GFR Calculator": "eGFR: 78 mL/min/1.73m² - CKD Stage 2 (mildly decreased)",
      "BMI Calculator": "BMI: 26.5 kg/m² - Overweight",
      "Creatinine Clearance": "CrCl: 85 mL/min - Normal renal function",
      "MELD Score": "MELD Score: 12 - 3-month mortality: 6%",
    }
    setCalculatorResult(results[calcName] || "Calculation complete")
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Medical Library</h1>
        <p className="text-muted-foreground">Guidelines, drug references, and clinical tools</p>
      </div>

      <div className="relative max-w-xl">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search guidelines, drugs, or calculators..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="guidelines">
        <TabsList>
          <TabsTrigger value="guidelines">Clinical Guidelines</TabsTrigger>
          <TabsTrigger value="drugs">Drug Reference</TabsTrigger>
          <TabsTrigger value="calculators">Calculators</TabsTrigger>
        </TabsList>

        <TabsContent value="guidelines" className="mt-6">
          <div className="grid md:grid-cols-2 gap-4">
            {filteredGuidelines.map((guide) => (
              <Card
                key={guide.id}
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedGuideline(guide)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-accent" />
                      <Badge variant="outline">{guide.category}</Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleStar(guide.id)
                      }}
                    >
                      <Star
                        className={`h-4 w-4 ${starredGuidelines.includes(guide.id) ? "fill-yellow-500 text-yellow-500" : ""}`}
                      />
                    </Button>
                  </div>
                  <CardTitle className="text-lg mt-2">{guide.title}</CardTitle>
                  <CardDescription>
                    {guide.source} • {guide.year}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Guideline
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="drugs" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Drug Reference Database</CardTitle>
              <CardDescription>Quick access to medication information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredDrugs.map((drug, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => setSelectedDrug(drug)}
                  >
                    <div>
                      <p className="font-medium flex items-center gap-2">
                        <Pill className="h-4 w-4 text-primary" />
                        {drug.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {drug.class} • {drug.indication}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">
                      <FileText className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calculators" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCalculators.map((calc, i) => (
              <Card
                key={i}
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedCalculator(calc)}
              >
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-accent" />
                    {calc.name}
                  </CardTitle>
                  <CardDescription>{calc.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full bg-transparent">
                    Open Calculator
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={!!selectedGuideline} onOpenChange={() => setSelectedGuideline(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{selectedGuideline?.title}</DialogTitle>
            <DialogDescription>
              {selectedGuideline?.source} • {selectedGuideline?.year}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Badge variant="outline">{selectedGuideline?.category}</Badge>
            <p className="text-sm">{selectedGuideline?.summary}</p>
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Always verify guideline recommendations with the latest published version.
              </AlertDescription>
            </Alert>
            <Button className="w-full" onClick={() => window.open(selectedGuideline?.url, "_blank")}>
              <ExternalLink className="h-4 w-4 mr-2" />
              View Full Guideline
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedDrug} onOpenChange={() => setSelectedDrug(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              {selectedDrug?.name}
            </DialogTitle>
            <DialogDescription>{selectedDrug?.class}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs text-muted-foreground">Indication</Label>
              <p className="font-medium">{selectedDrug?.indication}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Dosing</Label>
              <p className="font-medium">{selectedDrug?.dosing}</p>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Contraindications</Label>
              <p className="font-medium text-destructive">{selectedDrug?.contraindications}</p>
            </div>
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Verify dosing and contraindications with current prescribing information.
              </AlertDescription>
            </Alert>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!selectedCalculator}
        onOpenChange={() => {
          setSelectedCalculator(null)
          setCalculatorResult(null)
        }}
      >
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              {selectedCalculator?.name}
            </DialogTitle>
            <DialogDescription>{selectedCalculator?.description}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-3">
              {selectedCalculator?.inputs.map((input: string, i: number) => (
                <div key={i}>
                  <Label>{input}</Label>
                  <Input placeholder={`Enter ${input.toLowerCase()}`} />
                </div>
              ))}
            </div>
            {calculatorResult && (
              <Alert className="bg-primary/10 border-primary/20">
                <AlertDescription className="font-medium">{calculatorResult}</AlertDescription>
              </Alert>
            )}
            <Button className="w-full" onClick={() => runCalculator(selectedCalculator?.name)}>
              Calculate
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
