"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, Users, FileText, AlertTriangle } from "lucide-react"

export default function ClinicianDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Good morning, Dr. Smith</h1>
        <p className="text-muted-foreground">Here's your clinical overview for today</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">3 in-person, 5 telehealth</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">Lab results awaiting review</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Patients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">284</div>
            <p className="text-xs text-muted-foreground">+12 this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Critical Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">3</div>
            <p className="text-xs text-muted-foreground">Require immediate attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Today's Schedule */}
        <Card>
          <CardHeader>
            <CardTitle>Today's Schedule</CardTitle>
            <CardDescription>Your appointments for January 7, 2026</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { time: "9:00 AM", patient: "John Doe", type: "Follow-up", status: "Checked In" },
              { time: "9:30 AM", patient: "Sarah Wilson", type: "New Patient", status: "Upcoming" },
              { time: "10:00 AM", patient: "Michael Brown", type: "Annual Physical", status: "Upcoming" },
              { time: "10:30 AM", patient: "Emily Davis", type: "Telehealth", status: "Upcoming" },
            ].map((apt, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="text-center min-w-[60px]">
                    <p className="text-sm font-medium">{apt.time}</p>
                  </div>
                  <Avatar className="h-9 w-9">
                    <AvatarFallback className="text-xs bg-accent/10 text-accent">
                      {apt.patient
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-sm">{apt.patient}</p>
                    <p className="text-xs text-muted-foreground">{apt.type}</p>
                  </div>
                </div>
                <Badge variant={apt.status === "Checked In" ? "default" : "secondary"}>{apt.status}</Badge>
              </div>
            ))}
            <Button variant="outline" className="w-full bg-transparent">
              View Full Schedule
            </Button>
          </CardContent>
        </Card>

        {/* Critical Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Critical Alerts
            </CardTitle>
            <CardDescription>Items requiring immediate attention</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-sm">Critical Lab Value - Robert Chen</p>
                  <p className="text-xs text-muted-foreground mt-1">Potassium: 6.2 mEq/L (Critical High)</p>
                  <p className="text-xs text-muted-foreground">Received: 15 min ago</p>
                </div>
                <Button size="sm" variant="destructive">
                  Review
                </Button>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-sm">Abnormal ECG - Maria Garcia</p>
                  <p className="text-xs text-muted-foreground mt-1">New onset atrial fibrillation</p>
                  <p className="text-xs text-muted-foreground">Received: 1 hour ago</p>
                </div>
                <Button size="sm" variant="outline">
                  Review
                </Button>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-sm">Pending Authorization - James Lee</p>
                  <p className="text-xs text-muted-foreground mt-1">MRI Brain - requires approval</p>
                  <p className="text-xs text-muted-foreground">Submitted: 2 days ago</p>
                </div>
                <Button size="sm" variant="outline">
                  Approve
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Lab Results */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Pending Lab Reviews</CardTitle>
            <CardDescription>Recent results awaiting your review</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { patient: "John Doe", test: "CBC, CMP", date: "Today", status: "Normal" },
                { patient: "Alice Johnson", test: "Lipid Panel", date: "Today", status: "Abnormal" },
                { patient: "Tom Wilson", test: "HbA1c", date: "Yesterday", status: "Normal" },
                { patient: "Nancy Brown", test: "Thyroid Panel", date: "Yesterday", status: "Abnormal" },
                { patient: "David Lee", test: "Urinalysis", date: "Yesterday", status: "Normal" },
                { patient: "Lisa Park", test: "CBC", date: "2 days ago", status: "Normal" },
              ].map((lab, i) => (
                <div key={i} className="p-3 rounded-lg border hover:bg-muted/50 cursor-pointer transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-sm">{lab.patient}</p>
                    <Badge variant={lab.status === "Normal" ? "secondary" : "destructive"} className="text-xs">
                      {lab.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{lab.test}</p>
                  <p className="text-xs text-muted-foreground mt-1">{lab.date}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
