"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Calendar, Pill, AlertCircle, Activity } from "lucide-react"

const patients = [
  {
    id: 1,
    name: "John Doe",
    age: 45,
    gender: "Male",
    lastVisit: "Jan 5, 2026",
    conditions: ["Hypertension", "Type 2 Diabetes"],
    status: "Active",
  },
  {
    id: 2,
    name: "Sarah Wilson",
    age: 32,
    gender: "Female",
    lastVisit: "Dec 20, 2025",
    conditions: ["Asthma"],
    status: "Active",
  },
  {
    id: 3,
    name: "Michael Brown",
    age: 58,
    gender: "Male",
    lastVisit: "Jan 3, 2026",
    conditions: ["CAD", "Hyperlipidemia"],
    status: "Active",
  },
  {
    id: 4,
    name: "Emily Davis",
    age: 29,
    gender: "Female",
    lastVisit: "Nov 15, 2025",
    conditions: ["Anxiety", "Migraine"],
    status: "Active",
  },
  {
    id: 5,
    name: "Robert Chen",
    age: 67,
    gender: "Male",
    lastVisit: "Jan 2, 2026",
    conditions: ["CHF", "AFib", "CKD"],
    status: "Critical",
  },
]

const selectedPatientHistory = {
  demographics: {
    mrn: "MRN-12345",
    dob: "05/15/1980",
    phone: "(555) 123-4567",
    email: "john.doe@email.com",
    insurance: "Blue Cross PPO",
  },
  vitals: { bp: "128/82", hr: "72", temp: "98.6°F", weight: "185 lbs", height: "5'10\"", bmi: "26.5" },
  medications: [
    { name: "Lisinopril 10mg", dosage: "Once daily", status: "Active" },
    { name: "Metformin 500mg", dosage: "Twice daily", status: "Active" },
    { name: "Atorvastatin 20mg", dosage: "Once daily at bedtime", status: "Active" },
  ],
  recentVisits: [
    {
      date: "Jan 5, 2026",
      type: "Follow-up",
      provider: "Dr. Smith",
      notes: "BP well controlled. Continue current medications.",
    },
    { date: "Oct 12, 2025", type: "Annual Physical", provider: "Dr. Smith", notes: "Routine exam. Labs ordered." },
    {
      date: "Jul 8, 2025",
      type: "Sick Visit",
      provider: "Dr. Johnson",
      notes: "Upper respiratory infection. Prescribed antibiotics.",
    },
  ],
}

export default function PatientHistory() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState(patients[0])

  const filteredPatients = patients.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="p-6 h-[calc(100vh-1.5rem)]">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Patient History</h1>
        <p className="text-muted-foreground">View and manage patient records</p>
      </div>

      <div className="grid grid-cols-3 gap-6 h-[calc(100%-5rem)]">
        {/* Patient List */}
        <Card className="col-span-1">
          <CardHeader className="pb-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search patients..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[550px]">
              {filteredPatients.map((patient) => (
                <button
                  key={patient.id}
                  onClick={() => setSelectedPatient(patient)}
                  className={`w-full p-4 text-left border-b transition-colors hover:bg-muted/50 ${
                    selectedPatient.id === patient.id ? "bg-accent/10" : ""
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-accent/10 text-accent">
                        {patient.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-sm">{patient.name}</p>
                        <Badge
                          variant={patient.status === "Critical" ? "destructive" : "secondary"}
                          className="text-xs"
                        >
                          {patient.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {patient.age}y {patient.gender}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Last visit: {patient.lastVisit}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {patient.conditions.slice(0, 2).map((c, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {c}
                          </Badge>
                        ))}
                        {patient.conditions.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{patient.conditions.length - 2}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Patient Details */}
        <Card className="col-span-2">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Avatar className="h-14 w-14">
                  <AvatarFallback className="bg-accent/10 text-accent text-lg">
                    {selectedPatient.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle>{selectedPatient.name}</CardTitle>
                  <CardDescription>
                    {selectedPatient.age}y {selectedPatient.gender} • MRN: {selectedPatientHistory.demographics.mrn}
                  </CardDescription>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline">Add Note</Button>
                <Button>Start Visit</Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full justify-start rounded-none border-b bg-transparent h-auto p-0">
                <TabsTrigger
                  value="overview"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
                >
                  Overview
                </TabsTrigger>
                <TabsTrigger
                  value="medications"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
                >
                  Medications
                </TabsTrigger>
                <TabsTrigger
                  value="visits"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
                >
                  Visit History
                </TabsTrigger>
                <TabsTrigger
                  value="labs"
                  className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent"
                >
                  Labs
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="p-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg border">
                    <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <Activity className="h-4 w-4 text-accent" />
                      Latest Vitals
                    </h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-muted-foreground">BP:</span> {selectedPatientHistory.vitals.bp}
                      </div>
                      <div>
                        <span className="text-muted-foreground">HR:</span> {selectedPatientHistory.vitals.hr} bpm
                      </div>
                      <div>
                        <span className="text-muted-foreground">Temp:</span> {selectedPatientHistory.vitals.temp}
                      </div>
                      <div>
                        <span className="text-muted-foreground">BMI:</span> {selectedPatientHistory.vitals.bmi}
                      </div>
                    </div>
                  </div>
                  <div className="p-4 rounded-lg border">
                    <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 text-accent" />
                      Active Conditions
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedPatient.conditions.map((c, i) => (
                        <Badge key={i} variant="outline">
                          {c}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="p-4 rounded-lg border">
                  <h4 className="font-semibold text-sm mb-3">Contact Information</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Phone:</span> {selectedPatientHistory.demographics.phone}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Email:</span> {selectedPatientHistory.demographics.email}
                    </div>
                    <div>
                      <span className="text-muted-foreground">Insurance:</span>{" "}
                      {selectedPatientHistory.demographics.insurance}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="medications" className="p-4">
                <div className="space-y-3">
                  {selectedPatientHistory.medications.map((med, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <Pill className="h-5 w-5 text-accent" />
                        <div>
                          <p className="font-medium">{med.name}</p>
                          <p className="text-sm text-muted-foreground">{med.dosage}</p>
                        </div>
                      </div>
                      <Badge variant="secondary">{med.status}</Badge>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="visits" className="p-4">
                <div className="space-y-3">
                  {selectedPatientHistory.recentVisits.map((visit, i) => (
                    <div key={i} className="p-3 rounded-lg border">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{visit.date}</span>
                          <Badge variant="outline">{visit.type}</Badge>
                        </div>
                        <span className="text-sm text-muted-foreground">{visit.provider}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{visit.notes}</p>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="labs" className="p-4">
                <p className="text-muted-foreground text-center py-8">Lab results will be displayed here</p>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
