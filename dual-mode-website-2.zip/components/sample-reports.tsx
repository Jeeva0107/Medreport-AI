"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileImage, TestTube, Brain, Heart, Scan } from "lucide-react"

type Report = {
  id: string
  title: string
  category: string
  content: string
}

const iconMap: Record<string, React.ElementType> = {
  "chest-xray": FileImage,
  cbc: TestTube,
  "mri-brain": Brain,
  "lipid-panel": Heart,
  "ct-abdomen": Scan,
}

export function SampleReports({
  reports,
  onSelect,
}: {
  reports: Report[]
  onSelect: (content: string) => void
}) {
  return (
    <Card className="border-border">
      <CardHeader>
        <CardTitle className="text-foreground">Sample Reports</CardTitle>
        <CardDescription>Try these synthetic examples to see how the analysis works.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {reports.map((report) => {
            const Icon = iconMap[report.id] || FileImage
            return (
              <Button
                key={report.id}
                variant="outline"
                className="h-auto py-3 px-3 flex flex-col items-center gap-2 hover:border-primary hover:bg-primary/5 transition-colors bg-transparent"
                onClick={() => onSelect(report.content)}
              >
                <Icon className="h-5 w-5 text-primary" />
                <div className="text-center">
                  <div className="text-xs font-medium text-foreground leading-tight">{report.title}</div>
                  <div className="text-[10px] text-muted-foreground">{report.category}</div>
                </div>
              </Button>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
