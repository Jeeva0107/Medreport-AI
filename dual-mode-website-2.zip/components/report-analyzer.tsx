"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertTriangle, FileText, Stethoscope, User, Upload, Sparkles, ChevronDown } from "lucide-react"
import { SampleReports } from "@/components/sample-reports"
import { AnalysisResults } from "@/components/analysis-results"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export type ViewMode = "patient" | "clinician"
export type AnalysisResult = {
  patientSummary: {
    overview: string
    keyFindings: { finding: string; explanation: string; significance: "normal" | "attention" | "urgent" }[]
    questionsToAsk: string[]
    nextSteps: string[]
  }
  clinicianSummary: {
    impression: string
    criticalValues: { value: string; result: string; reference: string; flag: "normal" | "high" | "low" | "critical" }[]
    differentialConsiderations: string[]
    suggestedFollowUp: string[]
    relevantGuidelines: { guideline: string; source: string; url?: string }[]
  }
  citations: { title: string; source: string; url?: string }[]
}

const sampleReports = [
  {
    id: "chest-xray",
    title: "Chest X-Ray Report",
    category: "Radiology",
    content: `CHEST X-RAY - PA AND LATERAL VIEWS

CLINICAL HISTORY: 58-year-old male with cough and shortness of breath.

TECHNIQUE: PA and lateral chest radiographs were obtained.

FINDINGS:
Heart size is at the upper limits of normal. The mediastinal contours are within normal limits. There is mild prominence of the pulmonary vasculature. 

The lungs demonstrate patchy airspace opacity in the right lower lobe, measuring approximately 4cm in greatest dimension, concerning for pneumonia. No pleural effusion identified. No pneumothorax.

The visualized osseous structures are unremarkable.

IMPRESSION:
1. Right lower lobe airspace opacity, likely representing community-acquired pneumonia.
2. Mild cardiomegaly.
3. Recommend clinical correlation and follow-up imaging in 4-6 weeks to confirm resolution.`,
  },
  {
    id: "cbc",
    title: "Complete Blood Count",
    category: "Laboratory",
    content: `COMPLETE BLOOD COUNT (CBC) WITH DIFFERENTIAL

Patient: John Doe
DOB: 03/15/1965
Collection Date: 01/05/2026

TEST                    RESULT      REFERENCE RANGE    FLAG
White Blood Cell Count  12.5        4.5-11.0 K/uL      HIGH
Red Blood Cell Count    4.2         4.5-5.5 M/uL       LOW
Hemoglobin             11.8        13.5-17.5 g/dL     LOW
Hematocrit             35.2        38.0-50.0 %        LOW
MCV                    83.8        80-100 fL          
MCH                    28.1        27-33 pg           
MCHC                   33.5        32-36 g/dL         
RDW                    14.2        11.5-14.5 %        
Platelet Count         245         150-400 K/uL       

DIFFERENTIAL:
Neutrophils            78          40-70 %            HIGH
Lymphocytes            15          20-40 %            LOW
Monocytes              5           2-8 %              
Eosinophils            1           1-4 %              
Basophils              1           0-2 %              

INTERPRETATION:
Mild anemia with elevated WBC and neutrophilia, suggestive of acute infection or inflammatory process. Clinical correlation recommended.`,
  },
  {
    id: "mri-brain",
    title: "Brain MRI Report",
    category: "Radiology",
    content: `MRI BRAIN WITHOUT AND WITH CONTRAST

CLINICAL HISTORY: 45-year-old female with persistent headaches.

TECHNIQUE: Multiplanar, multisequence MRI of the brain was performed without and with IV gadolinium contrast.

FINDINGS:
Brain parenchyma demonstrates normal signal intensity on all sequences. No evidence of acute infarct on diffusion-weighted imaging.

A 6mm well-circumscribed, non-enhancing lesion is identified in the left frontal subcortical white matter, demonstrating T2/FLAIR hyperintensity. This is nonspecific and may represent a small area of gliosis or a demyelinating lesion.

No mass effect or midline shift. The ventricles and sulci are appropriate for age. No abnormal enhancement following contrast administration.

The major intracranial vessels demonstrate normal flow voids. No evidence of aneurysm.

IMPRESSION:
1. 6mm nonspecific T2/FLAIR hyperintense lesion in the left frontal subcortical white matter - differential includes small vessel ischemic change, demyelination, or migraine-related change. Clinical correlation and comparison with prior studies if available is recommended.
2. No acute intracranial abnormality.
3. No evidence of mass, hemorrhage, or hydrocephalus.`,
  },
  {
    id: "lipid-panel",
    title: "Lipid Panel Results",
    category: "Laboratory",
    content: `LIPID PANEL

Patient: Jane Smith
DOB: 07/22/1970
Collection Date: 01/05/2026
Fasting: Yes (12 hours)

TEST                        RESULT      REFERENCE RANGE    FLAG
Total Cholesterol           248         <200 mg/dL         HIGH
Triglycerides              185         <150 mg/dL         HIGH
HDL Cholesterol            42          >40 mg/dL (men)    
                                       >50 mg/dL (women)  LOW
LDL Cholesterol (calc)     169         <100 mg/dL         HIGH
VLDL Cholesterol           37          <30 mg/dL          HIGH
Total Cholesterol/HDL      5.9         <5.0               HIGH
Non-HDL Cholesterol        206         <130 mg/dL         HIGH

10-YEAR ASCVD RISK SCORE: 8.5%

INTERPRETATION:
Dyslipidemia with elevated LDL, elevated triglycerides, and low HDL. This lipid profile is associated with increased cardiovascular risk. Lifestyle modifications and consideration of pharmacotherapy per current ACC/AHA guidelines recommended.`,
  },
  {
    id: "ct-abdomen",
    title: "CT Abdomen/Pelvis",
    category: "Radiology",
    content: `CT ABDOMEN AND PELVIS WITH IV CONTRAST

CLINICAL HISTORY: 62-year-old male with abdominal pain and weight loss.

TECHNIQUE: Helical CT of the abdomen and pelvis was performed following administration of IV contrast.

FINDINGS:
LIVER: Normal size and attenuation. No focal hepatic lesions. No biliary dilatation.

GALLBLADDER: Normal. No gallstones.

PANCREAS: A 2.3 cm hypodense lesion is identified in the body of the pancreas. The lesion demonstrates poor enhancement and causes mild pancreatic duct dilation distally. The superior mesenteric artery and vein appear patent.

SPLEEN: Normal size and attenuation.

ADRENAL GLANDS: Normal bilaterally.

KIDNEYS: No hydronephrosis. Small simple cysts bilaterally, largest 1.2 cm on the right.

BOWEL: No evidence of obstruction or inflammatory changes.

LYMPH NODES: Few borderline enlarged peripancreatic lymph nodes, largest measuring 1.1 cm.

IMPRESSION:
1. 2.3 cm hypodense pancreatic body mass with associated distal pancreatic duct dilation - concerning for pancreatic malignancy. ERCP with brushings and/or EUS-guided biopsy recommended for tissue diagnosis.
2. Borderline peripancreatic lymphadenopathy - may represent reactive changes vs. nodal involvement.
3. Recommend tumor markers (CA 19-9) and multidisciplinary oncology consultation.`,
  },
]

export function ReportAnalyzer() {
  const [reportText, setReportText] = useState("")
  const [viewMode, setViewMode] = useState<ViewMode>("patient")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSampleSelect = (content: string) => {
    setReportText(content)
    setAnalysisResult(null)
    setError(null)
  }

  const handleAnalyze = async () => {
    if (!reportText.trim()) return

    setIsAnalyzing(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reportText }),
      })

      if (!response.ok) {
        throw new Error("Failed to analyze report")
      }

      const result = await response.json()
      setAnalysisResult(result)
    } catch (err) {
      setError("An error occurred while analyzing the report. Please try again.")
      console.error(err)
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <section id="analyzer" className="py-16 md:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <p className="text-sm font-medium text-primary mb-2 uppercase tracking-wider">Report Analyzer</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Analyze Your Medical Report
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Paste your radiology or lab report below to get AI-powered explanations tailored to your needs.
          </p>
        </div>

        {/* Disclaimer Banner */}
        <Alert className="mb-8 max-w-4xl mx-auto bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          <AlertDescription className="text-amber-800 dark:text-amber-200">
            <strong>Important:</strong> This tool is for educational purposes only and is not a substitute for
            professional medical advice. Always consult with your healthcare provider about your medical reports.
          </AlertDescription>
        </Alert>

        {/* Mode Toggle */}
        <div className="flex justify-center mb-8">
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as ViewMode)} className="w-full max-w-md">
            <TabsList className="grid w-full grid-cols-2 h-12">
              <TabsTrigger value="patient" className="flex items-center gap-2 text-sm">
                <User className="h-4 w-4" />
                Patient Mode
              </TabsTrigger>
              <TabsTrigger value="clinician" className="flex items-center gap-2 text-sm">
                <Stethoscope className="h-4 w-4" />
                Clinician Mode
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Input Section */}
          <div className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <FileText className="h-5 w-5 text-primary" />
                  Enter Your Report
                </CardTitle>
                <CardDescription>
                  Paste your medical report text below or select a sample report to see how it works.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Paste your radiology or lab report here..."
                  className="min-h-[300px] font-mono text-sm resize-none"
                  value={reportText}
                  onChange={(e) => {
                    setReportText(e.target.value)
                    setAnalysisResult(null)
                    setError(null)
                  }}
                />

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button onClick={handleAnalyze} disabled={!reportText.trim() || isAnalyzing} className="flex-1">
                    {isAnalyzing ? (
                      <>
                        <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4 mr-2" />
                        Analyze Report
                      </>
                    )}
                  </Button>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" className="sm:w-auto bg-transparent">
                        <Upload className="h-4 w-4 mr-2" />
                        Load Sample
                        <ChevronDown className="h-4 w-4 ml-2" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      {sampleReports.map((report) => (
                        <DropdownMenuItem key={report.id} onClick={() => handleSampleSelect(report.content)}>
                          <div className="flex flex-col">
                            <span className="font-medium">{report.title}</span>
                            <span className="text-xs text-muted-foreground">{report.category}</span>
                          </div>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardContent>
            </Card>

            {/* Sample Reports */}
            <SampleReports reports={sampleReports} onSelect={handleSampleSelect} />
          </div>

          {/* Results Section */}
          <div>
            {error && (
              <Alert className="mb-4 border-destructive/50 bg-destructive/10">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <AlertDescription className="text-destructive">{error}</AlertDescription>
              </Alert>
            )}

            <AnalysisResults result={analysisResult} viewMode={viewMode} isAnalyzing={isAnalyzing} />
          </div>
        </div>
      </div>
    </section>
  )
}
