"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  AlertCircle,
  CheckCircle,
  AlertTriangle,
  HelpCircle,
  ArrowRight,
  BookOpen,
  Stethoscope,
  MessageCircle,
  TrendingUp,
  TrendingDown,
  Minus,
  ExternalLink,
} from "lucide-react"
import type { ViewMode, AnalysisResult } from "@/components/report-analyzer"

export function AnalysisResults({
  result,
  viewMode,
  isAnalyzing,
}: {
  result: AnalysisResult | null
  viewMode: ViewMode
  isAnalyzing: boolean
}) {
  if (isAnalyzing) {
    return (
      <Card className="border-border h-full min-h-[400px] flex items-center justify-center">
        <CardContent className="text-center py-12">
          <div className="h-12 w-12 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Analyzing your report...</p>
          <p className="text-sm text-muted-foreground/70 mt-1">This may take a few moments</p>
        </CardContent>
      </Card>
    )
  }

  if (!result) {
    return (
      <Card className="border-border h-full min-h-[400px] flex items-center justify-center">
        <CardContent className="text-center py-12">
          <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="font-semibold text-foreground mb-2">No Analysis Yet</h3>
          <p className="text-sm text-muted-foreground max-w-xs mx-auto">
            Enter or paste a medical report and click &quot;Analyze Report&quot; to get started.
          </p>
        </CardContent>
      </Card>
    )
  }

  return viewMode === "patient" ? <PatientView result={result} /> : <ClinicianView result={result} />
}

function PatientView({ result }: { result: AnalysisResult }) {
  const getSignificanceIcon = (significance: "normal" | "attention" | "urgent") => {
    switch (significance) {
      case "normal":
        return <CheckCircle className="h-5 w-5 text-success" />
      case "attention":
        return <AlertTriangle className="h-5 w-5 text-warning" />
      case "urgent":
        return <AlertCircle className="h-5 w-5 text-destructive" />
    }
  }

  const getSignificanceBadge = (significance: "normal" | "attention" | "urgent") => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      normal: "secondary",
      attention: "outline",
      urgent: "destructive",
    }
    const labels = {
      normal: "Normal",
      attention: "Worth Discussing",
      urgent: "Important",
    }
    return (
      <Badge variant={variants[significance]} className="text-xs">
        {labels[significance]}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      {/* Overview */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <BookOpen className="h-5 w-5 text-primary" />
            What This Report Means
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-foreground leading-relaxed">{result.patientSummary.overview}</p>
        </CardContent>
      </Card>

      {/* Key Findings */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-foreground">Key Findings</CardTitle>
          <CardDescription>Important results explained in plain language</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {result.patientSummary.keyFindings.map((finding, index) => (
            <div key={index} className="flex gap-3 p-3 rounded-lg bg-muted/50">
              {getSignificanceIcon(finding.significance)}
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-foreground">{finding.finding}</span>
                  {getSignificanceBadge(finding.significance)}
                </div>
                <p className="text-sm text-muted-foreground">{finding.explanation}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Questions to Ask */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <MessageCircle className="h-5 w-5 text-primary" />
            Questions to Ask Your Doctor
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {result.patientSummary.questionsToAsk.map((question, index) => (
              <li key={index} className="flex items-start gap-2">
                <ArrowRight className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-foreground">{question}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Next Steps */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-foreground">Suggested Next Steps</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {result.patientSummary.nextSteps.map((step, index) => (
              <li key={index} className="flex items-start gap-2">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-xs font-medium text-primary">{index + 1}</span>
                </div>
                <span className="text-foreground">{step}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Citations */}
      <Citations citations={result.citations} />
    </div>
  )
}

function ClinicianView({ result }: { result: AnalysisResult }) {
  const getFlagIcon = (flag: "normal" | "high" | "low" | "critical") => {
    switch (flag) {
      case "normal":
        return <Minus className="h-4 w-4 text-muted-foreground" />
      case "high":
        return <TrendingUp className="h-4 w-4 text-warning" />
      case "low":
        return <TrendingDown className="h-4 w-4 text-chart-2" />
      case "critical":
        return <AlertCircle className="h-4 w-4 text-destructive" />
    }
  }

  const getFlagBadge = (flag: "normal" | "high" | "low" | "critical") => {
    const colors: Record<string, string> = {
      normal: "bg-muted text-muted-foreground",
      high: "bg-warning/15 text-warning-foreground border-warning/30",
      low: "bg-chart-2/15 text-chart-2 border-chart-2/30",
      critical: "bg-destructive/15 text-destructive border-destructive/30",
    }
    return (
      <span className={`px-2 py-0.5 text-xs font-medium rounded border ${colors[flag]}`}>{flag.toUpperCase()}</span>
    )
  }

  return (
    <div className="space-y-6">
      {/* Clinical Impression */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Stethoscope className="h-5 w-5 text-primary" />
            Clinical Impression
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-foreground leading-relaxed">{result.clinicianSummary.impression}</p>
        </CardContent>
      </Card>

      {/* Critical Values */}
      {result.clinicianSummary.criticalValues.length > 0 && (
        <Card className="border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-foreground">Critical Values & Abnormalities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 font-medium text-muted-foreground">Parameter</th>
                    <th className="text-left py-2 font-medium text-muted-foreground">Result</th>
                    <th className="text-left py-2 font-medium text-muted-foreground">Reference</th>
                    <th className="text-left py-2 font-medium text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {result.clinicianSummary.criticalValues.map((item, index) => (
                    <tr key={index} className="border-b border-border/50">
                      <td className="py-2 text-foreground font-medium">{item.value}</td>
                      <td className="py-2 text-foreground font-mono">{item.result}</td>
                      <td className="py-2 text-muted-foreground font-mono text-xs">{item.reference}</td>
                      <td className="py-2">
                        <div className="flex items-center gap-1.5">
                          {getFlagIcon(item.flag)}
                          {getFlagBadge(item.flag)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Differential Considerations */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-foreground">Differential Considerations</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {result.clinicianSummary.differentialConsiderations.map((item, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-primary font-medium">•</span>
                <span className="text-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Suggested Follow-Up */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-foreground">Suggested Follow-Up (Non-Prescriptive)</CardTitle>
          <CardDescription>Clinical decision support - not medical advice</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {result.clinicianSummary.suggestedFollowUp.map((item, index) => (
              <li key={index} className="flex items-start gap-2">
                <ArrowRight className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Relevant Guidelines */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-foreground">Relevant Clinical Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {result.clinicianSummary.relevantGuidelines.map((guideline, index) => (
            <div key={index} className="flex items-start justify-between gap-2 p-2 rounded bg-muted/50">
              <div>
                <p className="text-sm font-medium text-foreground">{guideline.guideline}</p>
                <p className="text-xs text-muted-foreground">{guideline.source}</p>
              </div>
              {guideline.url && (
                <a
                  href={guideline.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:text-primary/80"
                >
                  <ExternalLink className="h-4 w-4" />
                </a>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Citations */}
      <Citations citations={result.citations} />
    </div>
  )
}

function Citations({ citations }: { citations: AnalysisResult["citations"] }) {
  return (
    <Card className="border-border bg-muted/30">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">References & Citations</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-1.5 text-xs text-muted-foreground">
          {citations.map((citation, index) => (
            <li key={index} className="flex items-start gap-1.5">
              <span className="shrink-0">[{index + 1}]</span>
              <span>
                {citation.title} - {citation.source}
                {citation.url && (
                  <a
                    href={citation.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-1 text-primary hover:underline"
                  >
                    [Link]
                  </a>
                )}
              </span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}
