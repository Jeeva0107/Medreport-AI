"use client"

import { ShieldCheck, FileSearch, Users, BookOpen, Lock, Accessibility } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const features = [
  {
    icon: Users,
    title: "Dual-Mode Analysis",
    description: "Switch between patient-friendly explanations and detailed clinical summaries with a single click.",
  },
  {
    icon: FileSearch,
    title: "Smart Extraction",
    description:
      "AI automatically identifies key findings, critical values, and important observations from your reports.",
  },
  {
    icon: BookOpen,
    title: "Cited Sources",
    description: "All explanations reference trusted public sources like RSNA, CDC, NIH, and ACC/AHA guidelines.",
  },
  {
    icon: ShieldCheck,
    title: "Clear Disclaimers",
    description: "Prominent safety notices remind users this is educational content, not medical advice.",
  },
  {
    icon: Lock,
    title: "Privacy First",
    description: "Uses only synthetic/de-identified data. No real patient information is stored or transmitted.",
  },
  {
    icon: Accessibility,
    title: "Accessible Design",
    description: "Screen-reader friendly interface with clear contrast and semantic markup for all users.",
  },
]

export function Features() {
  return (
    <section id="features" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="text-sm font-medium text-primary mb-2 uppercase tracking-wider">Features</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Built for clarity and safety
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Our medical report analyzer is designed with patient safety, clinical accuracy, and accessibility in mind.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="group border-border bg-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <CardContent className="p-6">
                <div className="mb-4 inline-flex items-center justify-center h-12 w-12 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
