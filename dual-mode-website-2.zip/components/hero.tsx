"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, ShieldCheck, FileText, Users } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"

export function Hero() {
  const benefits = ["Synthetic data only", "Clear citations", "Two viewing modes"]

  return (
    <section className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 py-20 md:py-28">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            AI-Powered Medical Report Analysis
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6 text-balance">
            Understand Your Medical Reports <span className="text-primary">Clearly</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            AI-powered explanations for radiology and lab reports. Get patient-friendly summaries or clinician-focused
            highlights with citations to trusted sources.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button size="lg" className="group" asChild>
              <a href="#analyzer">
                Analyze a Report
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
            </Button>
            <Button size="lg" variant="outline" className="group bg-transparent" asChild>
              <a href="#features">
                <FileText className="mr-2 h-4 w-4" />
                See Features
              </a>
            </Button>
          </div>

          {/* Benefits */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground mb-10">
            {benefits.map((benefit) => (
              <div key={benefit} className="flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-primary" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>

          <Alert className="max-w-2xl mx-auto bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            <AlertDescription className="text-amber-800 dark:text-amber-200 text-sm">
              <strong>Important:</strong> This tool provides educational information only and is not a substitute for
              professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare provider.
            </AlertDescription>
          </Alert>
        </div>

        {/* Mode Cards Preview */}
        <div className="mt-16 grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <div className="bg-card border border-border rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Patient Mode</h3>
                <p className="text-xs text-muted-foreground">Simple, clear explanations</p>
              </div>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Plain language explanations of findings
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                What results may mean for you
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Questions to ask your doctor
              </li>
            </ul>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                <FileText className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Clinician Mode</h3>
                <p className="text-xs text-muted-foreground">Professional summaries</p>
              </div>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Bullet-point clinical summaries
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Critical values highlighted
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                Suggested next steps (non-prescriptive)
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
